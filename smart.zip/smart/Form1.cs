﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace smart
{
    public partial class Form1 : Form
    {
        SerialPort port;
        public Form1()
        {
            InitializeComponent();

            try //0번카메라를 기본으로 설정
            {
                axNeptuneCtrl1.Camera = 0;
            }
            catch (Exception exp)
            {
                string strExp = "카메라 실행 오류 - " + exp.Message;
                MessageBox.Show(strExp);
                throw;
            }
            CameraInitialize();
        }

        private void btn_capture_Click(object sender, EventArgs e)
        {
            imageCapture();

        }

        private void trackBar_zoom_Scroll(object sender, EventArgs e)
        {
            textBox_zoom.Text = (trackBar_zoom.Value / 10.0).ToString();
        }

        private void textBox_zoom_TextChanged(object sender, EventArgs e)
        {
            String val = textBox_zoom.Text;
            if (!val.Equals(""))
            {
                float v = float.Parse(val);
                if (v > 0 && v <= 5)
                {
                    trackBar_zoom.Value = (int)v * 10;
                    axNeptuneCtrl1.DigitalZoom(v);
                }
            }
        }

        private void trackBar_brightness_Scroll(object sender, EventArgs e)
        {
            textBox_brightness.Text = (trackBar_brightness.Value).ToString();
        }

        private void textBox_brightness_TextChanged(object sender, EventArgs e)
        {
            String val = textBox_brightness.Text;
            if (!val.Equals(""))
            {
                int v = int.Parse(val);
                if (v > 0 && v <= 10)
                    {
                    trackBar_brightness.Value = v;
                    axNeptuneCtrl1.BlackLevel = v*100;
                    }
            }
        }

        private void KeyPress_IncludeDot(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }
            if (keyCode == 46)
            {
                if (string.IsNullOrEmpty(textBox_zoom.Text) || textBox_zoom.Text.Contains('.') == true)
                {
                    e.Handled = true;
                }
            }
        }

        private void KeyPress_OnlyNum(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }
        }

        private void trackBar_hue_Scroll(object sender, EventArgs e)
        {
            textBox_hue.Text = (trackBar_hue.Value).ToString();
        }

        private void textBox_hue_TextChanged(object sender, EventArgs e)
        {
            String val = textBox_hue.Text;
            if (!val.Equals(""))
            {
                int v = int.Parse(val);

                if (v > 0 && v <= 10)
                {
                    trackBar_hue.Value = v;
                    axNeptuneCtrl1.Hue = v * 25;
                }
            }
        }

        private void trackBar_saturation_Scroll(object sender, EventArgs e)
        {
            textBox_saturation.Text = (trackBar_saturation.Value).ToString();
        }

        private void textBox_saturation_TextChanged(object sender, EventArgs e)
        {
            String val = textBox_saturation.Text;
            if (!val.Equals(""))
            {
                int v = int.Parse(val);

                if (v > 0 && v <= 10)
                {
                    trackBar_saturation.Value = v;
                    axNeptuneCtrl1.Saturation = v * 25;
                }
            }
        }

        private void CameraInitialize()
        {
            axNeptuneCtrl1.PixelFormat = 3; //이미지 색상 형식 , 3=YUV411, 4= YUV422 참조: http://m.blog.daum.net/baramjin/16011198?tp_nil_a=2
            axNeptuneCtrl1.Hue = 128;
            axNeptuneCtrl1.Saturation = 128;
            axNeptuneCtrl1.SizeX = 1024; //X축 사이즈 설정
            axNeptuneCtrl1.SizeY = 768; //Y사이즈 설정
            axNeptuneCtrl1.BlackLevel = 400;
            axNeptuneCtrl1.DigitalZoom(0);
            axNeptuneCtrl1.Acquisition = 1; //영상 재생
        }

        private void imageCapture()
        {
            string fileName = null;
            axNeptuneCtrl1.SaveImage(fileName = "capture" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", 100);
            WebClient cl = new WebClient();
            // fileName = "capture" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".jpg";
            try
            {
                cl.UploadFile("http://218.150.183.191:5000" + "/1.php", fileName);
              //  MessageBox.Show("Upload success");
            }
            catch (Exception ArgumentNullException)
            {
                MessageBox.Show("Upload failed");
            }
        }

        private void button_serial_Click(object sender, EventArgs e)
        {
            try
            {
                if(port == null)
                {
                    port = new SerialPort();
                    port.DataReceived += new SerialDataReceivedEventHandler(port_dataReceived);
                    port.PortName = "COM4"; //port번호
                    port.BaudRate = 9600;
                    port.DataBits = (int)8;
                    port.Parity = Parity.None;
                    port.StopBits = StopBits.One;
                    port.ReadTimeout = (int)500;
                    port.WriteTimeout = (int)500;
                    port.Open();
                }

                if(port.IsOpen)
                {
                    MessageBox.Show("시리얼 포트를 연결했습니다.");

                }

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }

        void port_dataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int intRecSize = port.BytesToRead;
            string strRecData;

            if (intRecSize != 0)
            {
                strRecData = "";
                byte[] buff = new byte[intRecSize];
                port.Read(buff, 0, intRecSize);
                for (int iTemp = 0; iTemp < intRecSize; iTemp++)
                {
                    strRecData += Convert.ToChar(buff[iTemp]);
                }
                if (strRecData.Substring(0,1).Equals("d"))
                {
                    imageCapture();
                }
            }

        }
    }
}