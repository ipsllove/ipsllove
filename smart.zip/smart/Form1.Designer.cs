﻿namespace smart
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axNeptuneCtrl1 = new AxNeptuneLib.AxNeptuneCtrl();
            this.btn_capture = new System.Windows.Forms.Button();
            this.zoon = new System.Windows.Forms.Label();
            this.trackBar_zoom = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_brightness = new System.Windows.Forms.TextBox();
            this.trackBar_brightness = new System.Windows.Forms.TrackBar();
            this.textBox_zoom = new System.Windows.Forms.TextBox();
            this.textBox_hue = new System.Windows.Forms.TextBox();
            this.trackBar_hue = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_saturation = new System.Windows.Forms.TextBox();
            this.trackBar_saturation = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.button_serial = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axNeptuneCtrl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_zoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_brightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_saturation)).BeginInit();
            this.SuspendLayout();
            // 
            // axNeptuneCtrl1
            // 
            this.axNeptuneCtrl1.Enabled = true;
            this.axNeptuneCtrl1.Location = new System.Drawing.Point(12, 29);
            this.axNeptuneCtrl1.Margin = new System.Windows.Forms.Padding(4);
            this.axNeptuneCtrl1.Name = "axNeptuneCtrl1";
            this.axNeptuneCtrl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axNeptuneCtrl1.OcxState")));
            this.axNeptuneCtrl1.Size = new System.Drawing.Size(384, 288);
            this.axNeptuneCtrl1.TabIndex = 0;
            // 
            // btn_capture
            // 
            this.btn_capture.Location = new System.Drawing.Point(764, 429);
            this.btn_capture.Margin = new System.Windows.Forms.Padding(4);
            this.btn_capture.Name = "btn_capture";
            this.btn_capture.Size = new System.Drawing.Size(159, 48);
            this.btn_capture.TabIndex = 1;
            this.btn_capture.Text = "Capture";
            this.btn_capture.UseVisualStyleBackColor = true;
            this.btn_capture.Click += new System.EventHandler(this.btn_capture_Click);
            // 
            // zoon
            // 
            this.zoon.AutoSize = true;
            this.zoon.Location = new System.Drawing.Point(761, 134);
            this.zoon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.zoon.Name = "zoon";
            this.zoon.Size = new System.Drawing.Size(56, 18);
            this.zoon.TabIndex = 2;
            this.zoon.Text = "Zoom";
            // 
            // trackBar_zoom
            // 
            this.trackBar_zoom.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar_zoom.Location = new System.Drawing.Point(853, 128);
            this.trackBar_zoom.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar_zoom.Maximum = 50;
            this.trackBar_zoom.Name = "trackBar_zoom";
            this.trackBar_zoom.Size = new System.Drawing.Size(176, 69);
            this.trackBar_zoom.TabIndex = 10;
            this.trackBar_zoom.TickFrequency = 10;
            this.trackBar_zoom.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar_zoom.Value = 10;
            this.trackBar_zoom.Scroll += new System.EventHandler(this.trackBar_zoom_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(761, 206);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 18);
            this.label1.TabIndex = 21;
            this.label1.Text = "Brightness";
            // 
            // textBox_brightness
            // 
            this.textBox_brightness.Location = new System.Drawing.Point(2149, 382);
            this.textBox_brightness.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_brightness.Name = "textBox_brightness";
            this.textBox_brightness.Size = new System.Drawing.Size(65, 28);
            this.textBox_brightness.TabIndex = 22;
            this.textBox_brightness.Text = "4";
            this.textBox_brightness.WordWrap = false;
            this.textBox_brightness.TextChanged += new System.EventHandler(this.textBox_brightness_TextChanged);
            this.textBox_brightness.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress_OnlyNum);
            // 
            // trackBar_brightness
            // 
            this.trackBar_brightness.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar_brightness.LargeChange = 3;
            this.trackBar_brightness.Location = new System.Drawing.Point(853, 200);
            this.trackBar_brightness.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar_brightness.Minimum = 1;
            this.trackBar_brightness.Name = "trackBar_brightness";
            this.trackBar_brightness.Size = new System.Drawing.Size(176, 69);
            this.trackBar_brightness.SmallChange = 5;
            this.trackBar_brightness.TabIndex = 5;
            this.trackBar_brightness.TickFrequency = 100;
            this.trackBar_brightness.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar_brightness.Value = 4;
            this.trackBar_brightness.Scroll += new System.EventHandler(this.trackBar_brightness_Scroll);
            // 
            // textBox_zoom
            // 
            this.textBox_zoom.Location = new System.Drawing.Point(2149, 310);
            this.textBox_zoom.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_zoom.Name = "textBox_zoom";
            this.textBox_zoom.Size = new System.Drawing.Size(65, 28);
            this.textBox_zoom.TabIndex = 4;
            this.textBox_zoom.Text = "1.0";
            this.textBox_zoom.WordWrap = false;
            this.textBox_zoom.TextChanged += new System.EventHandler(this.textBox_zoom_TextChanged);
            this.textBox_zoom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress_IncludeDot);
            // 
            // textBox_hue
            // 
            this.textBox_hue.Location = new System.Drawing.Point(2149, 459);
            this.textBox_hue.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_hue.Name = "textBox_hue";
            this.textBox_hue.Size = new System.Drawing.Size(65, 28);
            this.textBox_hue.TabIndex = 25;
            this.textBox_hue.Text = "5";
            this.textBox_hue.WordWrap = false;
            this.textBox_hue.TextChanged += new System.EventHandler(this.textBox_hue_TextChanged);
            this.textBox_hue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress_OnlyNum);
            // 
            // trackBar_hue
            // 
            this.trackBar_hue.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar_hue.LargeChange = 3;
            this.trackBar_hue.Location = new System.Drawing.Point(853, 277);
            this.trackBar_hue.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar_hue.Minimum = 1;
            this.trackBar_hue.Name = "trackBar_hue";
            this.trackBar_hue.Size = new System.Drawing.Size(176, 69);
            this.trackBar_hue.SmallChange = 5;
            this.trackBar_hue.TabIndex = 23;
            this.trackBar_hue.TickFrequency = 100;
            this.trackBar_hue.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar_hue.Value = 5;
            this.trackBar_hue.Scroll += new System.EventHandler(this.trackBar_hue_Scroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(761, 283);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 18);
            this.label2.TabIndex = 24;
            this.label2.Text = "Hue";
            // 
            // textBox_saturation
            // 
            this.textBox_saturation.Location = new System.Drawing.Point(2149, 536);
            this.textBox_saturation.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_saturation.Name = "textBox_saturation";
            this.textBox_saturation.Size = new System.Drawing.Size(65, 28);
            this.textBox_saturation.TabIndex = 28;
            this.textBox_saturation.Text = "5";
            this.textBox_saturation.WordWrap = false;
            this.textBox_saturation.TextChanged += new System.EventHandler(this.textBox_saturation_TextChanged);
            this.textBox_saturation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress_OnlyNum);
            // 
            // trackBar_saturation
            // 
            this.trackBar_saturation.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar_saturation.LargeChange = 3;
            this.trackBar_saturation.Location = new System.Drawing.Point(853, 353);
            this.trackBar_saturation.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar_saturation.Minimum = 1;
            this.trackBar_saturation.Name = "trackBar_saturation";
            this.trackBar_saturation.Size = new System.Drawing.Size(176, 69);
            this.trackBar_saturation.SmallChange = 5;
            this.trackBar_saturation.TabIndex = 26;
            this.trackBar_saturation.TickFrequency = 100;
            this.trackBar_saturation.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar_saturation.Value = 5;
            this.trackBar_saturation.Scroll += new System.EventHandler(this.trackBar_saturation_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(761, 359);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 27;
            this.label3.Text = "Saturation";
            // 
            // button_serial
            // 
            this.button_serial.Location = new System.Drawing.Point(598, 429);
            this.button_serial.Name = "button_serial";
            this.button_serial.Size = new System.Drawing.Size(149, 48);
            this.button_serial.TabIndex = 29;
            this.button_serial.Text = "아두이노 연결";
            this.button_serial.UseVisualStyleBackColor = true;
            this.button_serial.Click += new System.EventHandler(this.button_serial_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1087, 507);
            this.Controls.Add(this.button_serial);
            this.Controls.Add(this.textBox_saturation);
            this.Controls.Add(this.trackBar_saturation);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_hue);
            this.Controls.Add(this.trackBar_hue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_brightness);
            this.Controls.Add(this.trackBar_brightness);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_zoom);
            this.Controls.Add(this.trackBar_zoom);
            this.Controls.Add(this.zoon);
            this.Controls.Add(this.btn_capture);
            this.Controls.Add(this.axNeptuneCtrl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CameraControl";
            ((System.ComponentModel.ISupportInitialize)(this.axNeptuneCtrl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_zoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_brightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_hue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_saturation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxNeptuneLib.AxNeptuneCtrl axNeptuneCtrl1;
        private System.Windows.Forms.Button btn_capture;
        private System.Windows.Forms.Label zoon;
        private System.Windows.Forms.TrackBar trackBar_zoom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_brightness;
        private System.Windows.Forms.TrackBar trackBar_brightness;
        private System.Windows.Forms.TextBox textBox_zoom;
        private System.Windows.Forms.TextBox textBox_hue;
        private System.Windows.Forms.TrackBar trackBar_hue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_saturation;
        private System.Windows.Forms.TrackBar trackBar_saturation;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_serial;
    }
}

